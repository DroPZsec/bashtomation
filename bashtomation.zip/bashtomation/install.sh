#!/bin/bash
clear

## COLORS

blue='\033[94m'
red='\033[91m'
green='\033[92m'
orange='\033[93m'
reset='\e[0m'
magenta='\u001b[35m'
yellow='\u001b[33m'

sleep 1.0
echo -e "$red[$reset$blue*$reset$red]$reset$yellow Coded by:$reset$magenta"
figlet -f big "vDroPZz"
    sleep 1.0
echo -e $reset
clear
    sleep 1.0

echo -e "$orange###########################"
echo -e "#                         #"
echo -e "# $reset$blue --[DOWNLOAD/INSTALL]--$reset$orange #"
echo -e "#      $reset$blue by vDroPZz  $reset$orange      #"
echo -e "#                         #"
echo -e "###########################$reset"
    sleep 1.0
echo ""
echo ""
echo -e "$magenta"
figlet -f small "START DOWNLOAD"
echo -e "$reset"
    sleep 1.0
sudo apt-get install wafw00f
sudo apt-get install nmap
sudo apt-get install metasploit-framework
sudo apt-get install git
sudo gem install wpscan
sudo apt-get install wapiti
cd install_tree
sudo apt-get install commix
git clone https://github.com/commixproject/commix.git commix
cd commix
sudo python3 setup.py install
sudo python3 commix.py --install
cd ..
cd ..
sudo su
cd
git clone https://github.com/1N3/BruteX
exit
clear
    sleep 0.5
figlet -f big "FINISH!"
    sleep 1.0
clear
figlet -f small "Type ./bashtomation.sh to start!"
    sleep 2.0
exit
/bin/bash