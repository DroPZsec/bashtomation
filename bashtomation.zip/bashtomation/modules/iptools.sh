#!/bin/bash
clear

## COLORS

blue='\033[94m'
red='\033[91m'
green='\033[92m'
orange='\033[93m'
reset='\e[0m'
magenta='\u001b[35m'
yellow='\u001b[33m'

sleep 1.0
echo -e "$red[$reset$blue*$reset$red]$reset$yellow Coded by:$reset$magenta"
figlet -f big "vDroPZz"
    sleep 1.0
echo -e $reset
clear
    sleep 1.0

echo -e "$orange###########################"
echo -e "#                         #"
echo -e "#$reset$blue    --[IP-TOOLS]-- $reset$orange      #"
echo -e "#     $reset$blue by vDroPZz  $reset$orange       #"
echo -e "#                         #"
echo -e "###########################$reset"
    sleep 1.0
echo ""
echo ""
echo -e "$magenta"
figlet -f small "IP-TOOLBOX"
echo -e "$reset"
    sleep 1.0
echo ""
echo ""
echo -e "$red[$reset$blue 01 $reset$red]$reset$green WHOIS$reset"
    sleep 0.5
echo -e "$red[$reset$blue 02 $reset$red]$reset$green PORT SCAN$reset"
    sleep 0.5
echo -e "$red[$reset$blue 03 $reset$red]$reset$green OS-DETECTION$reset"
    sleep 0.5
echo -e "$red[$reset$blue 04 $reset$red]$reset$green PING TEST$reset"
    sleep 0.5
echo -e "$red[$reset$blue 05 $reset$red]$reset$green RECONNAISANCE$reset"
    sleep 0.5
echo -e "$red[$reset$blue 06 $reset$red]$reset$green SHELLSHOCK CHECK$reset"
    sleep 0.5
echo -e "$red[$reset$blue 07 $reset$red]$reset$green VULNEREABLE SCAN$reset"
    sleep 0.5
echo -e "$red[$reset$blue 08 $reset$red]$reset$green WAF-DETECTION$reset"
    sleep 0.5
echo -e "$red[$reset$blue 09 $reset$red]$reset$green NETDISCOVER$reset"
    sleep 0.5
echo -e "$red[$reset$blue 10 $reset$red]$reset$green TRACEROUTE$reset"
    sleep 0.5
echo -e "$red[$reset$blue 00 $reset$red]$reset$green BACK$reset"
    sleep 0.5
echo ""
echo ""
echo ""
echo -e "$green Your choice: $reset"
    read option;

if [ $option == 1 ]; then
    echo -e "$green Enter Target IP:$reset"
        read ip;
    whois $ip
    nmap -Pn $ip --script=whois-ip.nse --script-args whois.whodb=nofile
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read
fi
if [ $option == 2 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    nmap -Pn -sV $ip
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read
fi
if [ $option == 3 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    sudo nmap -Pn -O -sV $ip --script=address-info.nse
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read
fi
if [ $option == 4 ]; then
    echo -e "$green Enter Target IP:"
        read ip;
    ping -c 10 -s 528 $ip
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read
fi
if [ $option == 5 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    sudo whatweb $ip
    sudo dmitry -i -e $ip
    nmap -sT -Pn $ip -D 10.0.0.1,10.0.0.2,10.0.0.4
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read
fi
if [ $option == 6 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    nmap -sV -p80 $ip --script=http-shellshock
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue..."
        read
fi
if [ $option == 7 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    nmap -Pn $ip --script vuln
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue..."
        read
fi
if [ $option == 8 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    nmap -p80 $ip --script http-waf-detection
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue..."
        read
fi
if [ $option == 9 ]; then
    echo -e "$green Enter your Interface (eth0, wlan0...): $reset"
        read ip;
    sudo netdiscover -i $ip -r 192.168.2.0/24
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read
fi
if [ $option == 10 ]; then
    echo -e "Enter Target IP: $reset"
        read ip;
    sudo nmap $ip --traceroute
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue..."
        read
fi
if [ $option == 0 ]; then
    cd ..
    ./bashtomation.sh
fi
./iptools.sh
/bin/bash