#!/usr/bin/env python
# encoding: UTF-8

"""
Flattens JSON objects in Python. 
flatten_json flattens the hierarchy in your object which can be useful if you want to force your objects into a table.
"""

pass