#!/bin/bash
#[*] This Tool is only coded for ethical-hacking experience!
#[*] All illegal uses are at youre own risk!
#[*] Only use this Tool on Targets, that allow it you, or at youre own network!
#[*] This Tool was coded by vDroPZz (Github: DroPZsec). Please don't be a asshole and change my Code! I will strike you!
#

# COLORS

blue='\033[94m'
red='\033[91m'
green='\033[92m'
orange='\033[93m'
reset='\e[0m'
magenta='\u001b[35m'
yellow='\u001b[33m'

# DEVELOPER

clear
    sleep 1.0
echo -e "$red[$reset$blue*$reset$red]$reset$yellow Coded by:$reset$magenta"
figlet -f big "vDroPZz"
    sleep 1.0
        clear
echo -e "$red[$reset$blue*$reset$red]$reset$yellow Contacts:$reset$magenta"
figlet -f small "GitHub:"
figlet -f big "DroPZsec"
echo -e $reset
    sleep 1.0
echo -e "$red[$reset$blue*$reset$red]$reset$green Contact me there if you have a question!$reset"
    sleep 2.0
clear

# CODE

sleep 1.0
echo -e "$orange###########################"
echo -e "#                         #"
echo -e "#$reset$blue   --[BASHTOMATION]-- $reset$orange   #"
echo -e "#     $reset$blue by vDroPZz  $reset$orange       #"
echo -e "#                         #"
echo -e "###########################$reset"
    sleep 1.0
echo ""
echo ""
echo -e "$magenta"
figlet -f small MAIN MENU
    sleep 1.0
echo ""
echo ""
echo -e "$reset"

echo -e "$red[$reset$blue 01 $reset$red]$reset$green IP-TOOLS$reset"
    sleep 0.5
echo -e "$red[$reset$blue 02 $reset$red]$reset$green CUSTOM NMAP SCRIPT SCANS$reset"
    sleep 0.5
echo -e "$red[$reset$blue 03 $reset$red]$reset$green WEBSCAN ATTACKS$reset"
    sleep 0.5
echo -e "$red[$reset$blue 04 $reset$red]$reset$green HEAVY SMB EXPLOITING$reset"
    sleep 0.5
echo -e "$red[$reset$blue 05 $reset$red]$reset$green XTRA HACKS$reset"
    sleep 0.5
echo -e "$red[$reset$blue 00 $reset$red]$reset$green EXIT$reset"
    sleep 0.5
echo ""
echo ""
echo "" 
echo -e "$green Your choice: $reset"
    read option;

if [ $option == 1 ]; then
    cd modules && ./iptools.sh
fi

if [ $option == 2 ]; then
    cd modules && ./customnmapscans.sh
fi

if [ $option == 3 ]; then
    cd modules && ./webmode.sh
fi

if [ $option == 4 ]; then
    cd modules && ./smbsploiting.sh
fi

if [ $option == 5 ]; then
    cd modules && ./other.sh
fi

if [ $option == 0 ]; then
    clear
        sleep 0.5
    echo -e "$red[$reset$blue*$reset$red]$reset$yellow Coded by:$reset$magenta"
    figlet -f big "vDroPZz"
        sleep 2.0
    clear
    echo -e "$red[$reset$blue*$reset$red]$reset$yellow Contacts:$reset$magenta"
    figlet -f small "GitHub:"
        sleep 2.0
    figlet -f big "DroPZsec"
    echo -e $reset
        sleep 2.0
    clear
    echo -e "$magenta"
    figlet -f big "Bye"
    echo -e "$reset"
exit
fi

./bashtomation.sh
/bin/bash